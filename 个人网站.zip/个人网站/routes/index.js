var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('main');
});
router.get('/information.html',function (req, res, next) {
  res.render('information');
});
router.get('/case.html',function (req, res, next) {
  res.render('case');
});
router.get('/register.html',function (req, res, next) {
  res.render('register');
});
router.get('/about.html',function (req, res, next) {
  res.render('about');
});
router.get('/main.html',function (req, res, next) {
  res.render('main');
});
router.get('/mousemove.html',function (req, res, next) {
  res.render('mousemove');
});
router.get('/control_div.html', function (req, res, next) {
    res.render('control_div');
});
router.get('/tengxunblog.html', function (req, res, next) {
    res.render('tengxunblog');
});
router.get('/carousel.html', function (req, res, next) {
   res.render('carousel') ;
});
module.exports = router;
