/**
 * Created by Administrator on 2016/11/5.
 */
var mysql = require('mysql');
var express = require('express');
var router = express.Router();

router.post('/', function (req, res) {
    var mysql = require('mysql');
    var conn = mysql.createConnection({
        host:'127.0.0.1',
        port:'3306',
        user:'root',
        password:'',
        database:'demo'
    });
    // console.log(req.body);
    // console.log(req.body.password);


    var SQL = 'select * from user_info where user="'+req.body.user+'"';
    conn.query(SQL, function (err, data) {
        console.log(data);
        if(err){
            console.log(err.message);
        }else if(data.length == 0){
            res.end('用户名不存在！');
        }else if(req.body.password == data[0].password){
            res.end('登录成功！');
        }else {
            res.end('密码错误！');
        }
    });
});
router.post('/register', function (req, res) {
    var mysql = require('mysql');
    var conn = mysql.createConnection({
        host:'127.0.0.1',
        port:'3306',
        user:'root',
        password:'',
        database:'demo'
    });
    var SQL = 'insert into user_info(user, password, email) values(?,?,?)';
    var user = req.body.user,
        password = req.body.password,
        email = req.body.email;
    conn.query(SQL, [user, password, email], function (err, data) {
        if(err){
            console.log(err.message);
            res.end('注册失败！')
        }else {
            res.end('注册成功！');
            console.log('注册成功！');
        }
    });
});
module.exports = router;