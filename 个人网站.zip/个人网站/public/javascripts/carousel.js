/**
 * Created by Administrator on 2016/10/20.
 */
$(function () {
    //自动播放，实现轮播
    var shuffling_index = 0;
    function shuffling_fn() {
        if(shuffling_index >= 3){ shuffling_index = 0;}
        $('#shuffling img').fadeOut();
        $('#shuffling ul li').css('color', '#666');
        $('#shuffling img').eq(shuffling_index).fadeIn();
       // $('#shuffling img').eq(shuffling_index).fadeIn('slow', 'block');
        $('#shuffling ul li').eq(shuffling_index).css('color', '#fff');
        shuffling_index ++;
    }
    var shuffling_timer = setInterval(shuffling_fn, 2000);

    //手动播放图片
    $('#shuffling ul li').hover(function () {
        clearInterval(shuffling_timer);
        shuffling_index = $(this).index() + 1;
        $('#shuffling ul li').css('color', '#666');
        $('#shuffling img').fadeOut('clip');
        $('#shuffling img').eq($(this).index()).fadeIn('clip');
        $('#shuffling ul li').eq($(this).index()).css('color', '#fff');
    }, function () {
        $('#shuffling ul li').eq($(this).index()).css('color', '#666');
        shuffling_timer = setInterval(shuffling_fn, 1000);
    });
//透明度切换尚未实现

});