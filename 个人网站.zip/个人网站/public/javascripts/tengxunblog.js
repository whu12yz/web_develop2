/**
 * Created by Administrator on 2016/10/23.
 */
$(function () {
    // function getName() {
    //     value = $('#userName').val();
    //     alert(value);
    //     return value;
    // }
    // function getText() {
    //     value = $('#conBox').val();
    //     alert(value);
    //     return value;
    // };


    $('#guangbo_button').click(function () {

        var name = $('#userName').val();
        var text = $('#conBox').val();
        if(name&&text){
            var time = new Date();
            var oLi = "<li><div class='content_list'><p>"+name+' : '+text+"</p><p class='timer'>"+time.getFullYear()+"年"+(time.getMonth()+1)+"月"+time.getDate()+"日"+time.getHours()+":"+time.getMinutes()+"<a href='###' class='li_delete'>删除</a></p> </div></li>";
            $(oLi).hide().prependTo($('#conList ul')).slideDown();
            $('#msgBox, #conList, #conList ul').animate({height : '+=100px'});
            $('#myform')[0].reset();
            $('.count_number').html(140);
            hover();
            // for(var i = 1; i <= $('#conList ul li').length; i ++){
            //     $('#conList ul li').eq(i).animate({bottom :'100px'});
            // };
            // $('#conList ul li ').eq(0).slideDown();
            //因为这是在表单中的按钮，默认自动提交。网页会刷新，加上return false可取消自动提交
            return false;
        }else {
            alert('请输入用户名以及发表内容');
            return false;
        }

    });
    $('#guangbo_button').hover(function () {
        $('#guangbo_button').css('background', '#9DD72C')
    }, function () {
        $('#guangbo_button').css('background', '#84C02C')
    })
    function hover() {
        $('#conList ul li').hover(function () {
            var _this = $(this).index();
            $('#conList ul li').eq(_this).css('background', '#F5F5F5');
            $('.li_delete').eq(_this).fadeIn();
            $('.li_delete').eq(_this).click(function () {
                $('#conList ul li').eq(_this).fadeOut();
            });

        }, function () {
            $('#conList ul li').eq($(this).index()).css('background', 'white');
            $('.li_delete').eq($(this).index()).fadeOut();
        });
    };
    hover();
    $('#conBox').keydown(function () {
        var text = $('#conBox').val().length;
        var number =140 -  $('#conBox').val().length;
        $('.count_number').html(number);
    });
    //easing 效果测试
    // $('#test').click(function () {
    //     $('#test').animate({width: '+400px'},'5000', 'easeOutElastic');
    // });





});