/**
 * Created by Administrator on 2016/11/3.
 */
//所需要的 jQuery 控制
$('#myCarousel').carousel({
//设置自动播放/2 秒
    interval : 3000,
});

//谷歌浏览器解析的顺序调整，需要全部加载后执行
$(window).load(function () {
    //调整轮播器箭头位置
    $('.carousel-control').css('line-height', $('.carousel-inner img').height() + 'px');
    //文字居中
    $('.text').eq(0).css('margin-top', ($('.auto').eq(0).height() - $('.text').eq(0).height()) / 2 + 'px');
    $('.text').eq(1).css('margin-top', ($('.auto').eq(1).height() - $('.text').eq(1).height()) / 2 + 'px');

});
$(window).resize(function() {
    var $height = 	$('.carousel-inner img').eq(0).height() ||
        $('.carousel-inner img').eq(1).height() ||
        $('.carousel-inner img').eq(2).height();
    $('.carousel-control').css('line-height', $height + 'px');
    $('.text').eq(0).css('margin-top', ($('.auto').eq(0).height() - $('.text').eq(0).height()) / 2 + 'px');
    $('.text').eq(1).css('margin-top', ($('.auto').eq(1).height() - $('.text').eq(1).height()) / 2 + 'px');
});
$(function () {


    function centerModals() {
        $('#myModal').each(function(i) {
            var $clone = $(this).clone().css('display', 'block').appendTo('body');
            var top = Math.round(($clone.height() - $clone.find('.modal-content').height()) / 2);
            top = top > 0 ? top : 0;
            $clone.remove();
            $(this).find('.modal-content').css("margin-top", top);
        });
    }
    $('#myModal').on('show.bs.modal', centerModals);
    $(window).on('resize', centerModals);
    $('#myform').validate({
        rules:{
                user:{
                    required:true
                },
                password:{
                    required:true
                }
        },
        messages:{
            user:{
                required:'用户名不能为空！'
            },
            password:{
                required:'密码不能为空！'
            }
        }
    });
    $('#reg_form').validate({
        rules:{
                user:{
                    required:true,
                    minlength:3
                },
                password:{
                    required:true,
                    minlength:6
                },
                email:{
                    required:true,
                    email:true
                }
        },
        messages:{
                user:{
                    required:'账户名不能为空！',
                    minlength:jQuery.format('账户名不能小于{0}位！')
                },

                password:{
                    required:'密码不能为空！',
                    minlength:jQuery.format('密码不能少于{0}位！')
                },
                email:{
                    required:'邮箱不能为空！',
                    email:'请输入正确的邮箱地址！'
                }
        }
    });
//     $('#log').on('click', function () {
//         $.get("../routes/login" , function(data){
// //
//             var dataObj = JSON.parse(data);//转换为json对象
// //
//             $('#login_user').val(dataObj[0].name);
//             $('#login_pass').val(dataObj[0].password);
//
//         })
//     });

    //点击时触发ajax
    $('#data_submit').on('click', function () {
//         $.get("/login" ,{}, function (response, status, xhr) {
//             var dataObj = JSON.parse(response);//转换为json对象
// //
//             $('#login_user').val(dataObj[0].name);
//             $('#login_pass').val(dataObj[0].password);
//         })
        //上传数据并进行登录验证，返回相应结果，确定是否登录成功
        $.post('/login',$('#myform').serialize(), function (response, status, xhr) {
            if($(' #attention')){
                $('#attention').css('display', 'none');
            }
            $('#myform p').eq(1).after('<p id="attention">'+response+'</p>');
            //切换页面
            if(response =='登录成功！'){
                $('#myModal').modal('hide');
                $('#log').html('<span class="glyphicon glyphicon-user"></span> 注销').css('color', '#777');
            }
        });
    });
    //注销登录
    $('#log').on('click', function () {
        var text = $('#log').text();
        if(text == ' 注销'){
            location.reload();

        }
    });
    //关闭登录窗口，清空数据
    $('#myModal').on('hidden.bs.modal', function () {
        $('#login_user').val('');
        $('#login_pass').val('');
        if($('#attention')){
            $('#attention').css('display', 'none');
        }

    });
    //注册页面ajax提交数据到服务端并进行存储使用form插件，实现先验证，验证成功之后再提交。


        $('#reg_form').submit(function () {
            $(this).ajaxSubmit({
                type:'POST',
                url:'/login/register',
                clearForm:true,
                beforeSubmit:function () {
                    if($("#reg_form").valid()==false){
                        return false;
                    }else {
                    }
                },
                success:function (response, status) {
                    alert(response);
                    //跳转至主页
                    // location.assign('/main.html');
                }
            });
            return false;
        });


});